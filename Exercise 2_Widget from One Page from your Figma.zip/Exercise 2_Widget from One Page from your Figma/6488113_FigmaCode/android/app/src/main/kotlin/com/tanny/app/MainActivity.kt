package com.tanny.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
