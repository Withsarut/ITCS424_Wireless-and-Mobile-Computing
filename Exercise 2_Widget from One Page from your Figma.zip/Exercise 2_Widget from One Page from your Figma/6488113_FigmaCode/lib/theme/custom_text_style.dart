import 'package:flutter/material.dart';
import '../core/app_export.dart';

/// A collection of pre-defined text styles for customizing text appearance,
/// categorized by different font families and weights.
/// Additionally, this class includes extensions on [TextStyle] to easily apply specific font families to text.

class CustomTextStyles {
  // Body text style
  static get bodyMediumGray60001 => theme.textTheme.bodyMedium!.copyWith(
        color: appTheme.gray60001,
        fontSize: 14.fSize,
      );
  static get bodySmallGray500 => theme.textTheme.bodySmall!.copyWith(
        color: appTheme.gray500,
      );
  static get bodySmallSFProTextGray600 =>
      theme.textTheme.bodySmall!.sFProText.copyWith(
        color: appTheme.gray600,
      );
  static get bodySmallff302d2c => theme.textTheme.bodySmall!.copyWith(
        color: Color(0XFF302D2C),
      );
  static get bodySmallffb6b1ae => theme.textTheme.bodySmall!.copyWith(
        color: Color(0XFFB6B1AE),
      );
  // Title text style
  static get titleMediumBluegray90001 => theme.textTheme.titleMedium!.copyWith(
        color: appTheme.blueGray90001,
        fontWeight: FontWeight.w500,
      );
  static get titleSmallGray800 => theme.textTheme.titleSmall!.copyWith(
        color: appTheme.gray800,
      );
  static get titleSmallGray900 => theme.textTheme.titleSmall!.copyWith(
        color: appTheme.gray900,
      );
  static get titleSmallff020000 => theme.textTheme.titleSmall!.copyWith(
        color: Color(0XFF020000),
        fontSize: 15.fSize,
        fontWeight: FontWeight.w600,
      );
}

extension on TextStyle {
  TextStyle get sFProText {
    return copyWith(
      fontFamily: 'SF Pro Text',
    );
  }

  TextStyle get poppins {
    return copyWith(
      fontFamily: 'Poppins',
    );
  }

  TextStyle get poly {
    return copyWith(
      fontFamily: 'Poly',
    );
  }
}
