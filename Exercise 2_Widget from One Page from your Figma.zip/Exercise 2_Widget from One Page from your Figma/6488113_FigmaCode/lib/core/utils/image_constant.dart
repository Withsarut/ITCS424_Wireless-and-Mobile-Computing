class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // Book Details images
  static String imgArrowDown = '$imagePath/img_arrow_down.svg';

  static String imgSignal = '$imagePath/img_signal.svg';

  static String imgComputer = '$imagePath/img_computer.svg';

  static String imgThumbsUp = '$imagePath/img_thumbs_up.svg';

  static String imgImage13 = '$imagePath/img_image_13.png';

  static String imgCover11 = '$imagePath/img_cover_1_1.png';

  static String imgImage12 = '$imagePath/img_image_12.png';

  static String imgImage10 = '$imagePath/img_image_10.png';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
