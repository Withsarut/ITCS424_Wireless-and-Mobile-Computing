import 'package:flutter/material.dart';
import 'package:tanny/presentation/book_details_screen/book_details_screen.dart';

class AppRoutes {
  static const String bookDetailsScreen = '/book_details_screen';

  static Map<String, WidgetBuilder> routes = {
    bookDetailsScreen: (context) => BookDetailsScreen()
  };
}
