import '../book_details_screen/widgets/cardlist_item_widget.dart';
import '../book_details_screen/widgets/scorecomponent_item_widget.dart';
import 'package:flutter/material.dart';
import 'package:tanny/core/app_export.dart';
import 'package:tanny/widgets/app_bar/appbar_leading_image.dart';
import 'package:tanny/widgets/app_bar/appbar_title.dart';
import 'package:tanny/widgets/app_bar/custom_app_bar.dart';
import 'package:tanny/widgets/custom_elevated_button.dart';

class BookDetailsScreen extends StatelessWidget {
  const BookDetailsScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: _buildAppBar(context),
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(vertical: 3.v),
          child: Column(
            children: [
              SizedBox(
                height: 490.v,
                width: 389.h,
                child: Stack(
                  alignment: Alignment.topLeft,
                  children: [
                    Align(
                      alignment: Alignment.center,
                      child: SizedBox(
                        height: 486.v,
                        width: 386.h,
                        child: Stack(
                          alignment: Alignment.topRight,
                          children: [
                            Align(
                              alignment: Alignment.center,
                              child: Container(
                                padding: EdgeInsets.symmetric(
                                  horizontal: 8.h,
                                  vertical: 17.v,
                                ),
                                decoration:
                                    AppDecoration.outlineBlackA.copyWith(
                                  borderRadius:
                                      BorderRadiusStyle.roundedBorder10,
                                ),
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Align(
                                      alignment: Alignment.centerLeft,
                                      child: Container(
                                        height: 274.v,
                                        width: 170.h,
                                        margin: EdgeInsets.only(left: 6.h),
                                        decoration: BoxDecoration(
                                          color: appTheme.gray30001,
                                          borderRadius: BorderRadius.circular(
                                            14.h,
                                          ),
                                        ),
                                      ),
                                    ),
                                    SizedBox(height: 12.v),
                                    Container(
                                      width: 356.h,
                                      margin: EdgeInsets.only(left: 11.h),
                                      child: RichText(
                                        text: TextSpan(
                                          children: [
                                            TextSpan(
                                              text: "Description\n",
                                              style: CustomTextStyles
                                                  .titleSmallff020000,
                                            ),
                                            TextSpan(
                                              text:
                                                  "หนังสือเล่มนี้จะพลิกชีวิตการสร้างรายได้ของคุณไปตลอดกาล ไม่ว่าคุณจะประกอบอาชีพอะไร หรือเคยมีประสบการณ์ทำกำไรในรูปแบบของการเทรดมาก่อนหรือไม่ ",
                                              style: theme.textTheme.bodyMedium,
                                            ),
                                            TextSpan(
                                              text: " ",
                                            ),
                                            TextSpan(
                                              text: "See More…",
                                              style: CustomTextStyles
                                                  .bodySmallff302d2c,
                                            ),
                                          ],
                                        ),
                                        textAlign: TextAlign.left,
                                      ),
                                    ),
                                    SizedBox(height: 18.v),
                                    _buildScoreComponent(context),
                                    SizedBox(height: 15.v),
                                  ],
                                ),
                              ),
                            ),
                            Align(
                              alignment: Alignment.topRight,
                              child: Padding(
                                padding: EdgeInsets.only(
                                  left: 211.h,
                                  top: 11.v,
                                  right: 22.h,
                                ),
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    SizedBox(
                                      width: 152.h,
                                      child: Text(
                                        "Trading Cryptocurrency",
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                        style: theme.textTheme.titleLarge,
                                      ),
                                    ),
                                    SizedBox(height: 7.v),
                                    Text(
                                      "กิตติพจน อินทะเสบ์ ",
                                      style:
                                          CustomTextStyles.bodyMediumGray60001,
                                    ),
                                    Text(
                                      "Description",
                                      style: CustomTextStyles.titleSmallGray900,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    CustomImageView(
                      imagePath: ImageConstant.imgImage13,
                      height: 296.v,
                      width: 194.h,
                      alignment: Alignment.topLeft,
                    ),
                  ],
                ),
              ),
              SizedBox(height: 12.v),
              Align(
                alignment: Alignment.centerLeft,
                child: Padding(
                  padding: EdgeInsets.only(left: 14.h),
                  child: Text(
                    "Related Book",
                    style: CustomTextStyles.titleMediumBluegray90001,
                  ),
                ),
              ),
              SizedBox(height: 14.v),
              _buildCardList(context),
            ],
          ),
        ),
        bottomNavigationBar: _buildAddToCart(context),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      leadingWidth: 36.h,
      leading: AppbarLeadingImage(
        imagePath: ImageConstant.imgArrowDown,
        margin: EdgeInsets.only(
          left: 18.h,
          top: 15.v,
          bottom: 20.v,
        ),
      ),
      centerTitle: true,
      title: AppbarTitle(
        text: "Book Details",
      ),
    );
  }

  /// Section Widget
  Widget _buildScoreComponent(BuildContext context) {
    return SizedBox(
      height: 38.v,
      child: ListView.separated(
        padding: EdgeInsets.symmetric(horizontal: 26.h),
        scrollDirection: Axis.horizontal,
        separatorBuilder: (
          context,
          index,
        ) {
          return Padding(
            padding: EdgeInsets.symmetric(horizontal: 34.0.h),
            child: SizedBox(
              height: 38.v,
              child: VerticalDivider(
                width: 1.h,
                thickness: 1.v,
                color: appTheme.gray100,
              ),
            ),
          );
        },
        itemCount: 3,
        itemBuilder: (context, index) {
          return ScorecomponentItemWidget();
        },
      ),
    );
  }

  /// Section Widget
  Widget _buildCardList(BuildContext context) {
    return SizedBox(
      height: 165.v,
      child: ListView.separated(
        padding: EdgeInsets.only(left: 14.h),
        scrollDirection: Axis.horizontal,
        separatorBuilder: (
          context,
          index,
        ) {
          return SizedBox(
            width: 14.h,
          );
        },
        itemCount: 3,
        itemBuilder: (context, index) {
          return CardlistItemWidget();
        },
      ),
    );
  }

  /// Section Widget
  Widget _buildAddToCart(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(
        left: 14.h,
        right: 14.h,
        bottom: 12.v,
      ),
      decoration: AppDecoration.outlineBlack9000a,
      child: CustomElevatedButton(
        text: "ADD TO order".toUpperCase(),
      ),
    );
  }
}
