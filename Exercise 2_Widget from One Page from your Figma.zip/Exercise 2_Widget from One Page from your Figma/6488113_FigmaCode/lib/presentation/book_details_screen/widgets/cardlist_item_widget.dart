import 'package:flutter/material.dart';
import 'package:tanny/core/app_export.dart';

// ignore: must_be_immutable
class CardlistItemWidget extends StatelessWidget {
  const CardlistItemWidget({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: 4.h,
        vertical: 9.v,
      ),
      decoration: AppDecoration.outlineBlackA.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder14,
      ),
      width: 143.h,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(height: 4.v),
          Container(
            margin: EdgeInsets.symmetric(horizontal: 9.h),
            decoration: AppDecoration.fillGray.copyWith(
              borderRadius: BorderRadiusStyle.roundedBorder10,
            ),
            child: Container(
              height: 87.v,
              width: 115.h,
              decoration: AppDecoration.fillGray30001.copyWith(
                borderRadius: BorderRadiusStyle.roundedBorder10,
              ),
              child: CustomImageView(
                imagePath: ImageConstant.imgCover11,
                height: 87.v,
                width: 112.h,
                radius: BorderRadius.circular(
                  10.h,
                ),
                alignment: Alignment.center,
              ),
            ),
          ),
          SizedBox(height: 13.v),
          Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: EdgeInsets.only(left: 9.h),
              child: Text(
                "Crypto VI",
                style: CustomTextStyles.titleSmallGray800,
              ),
            ),
          ),
          SizedBox(height: 1.v),
          Text(
            "Education,financial",
            style: CustomTextStyles.bodySmallGray500,
          ),
        ],
      ),
    );
  }
}
